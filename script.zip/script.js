const weightInput = document.querySelector('#weight');
const trainingType = document.querySelector('#training-type');
const calculateButton = document.querySelector('#calculate');
const proteinResult = document.querySelector('#protein-result');
const proteinSource = document.querySelector('#protein-source');
const generateButton = document.querySelector('#generate');
const dishCard = document.querySelector('#dish-card');
const mealChoice = document.querySelector('#meal-choice');
const chooseMealButton = document.querySelector('#choose-meal');
const mealSelectionHint = document.querySelector('#meal-selection-hint');
const resultsSection = document.querySelector('#results');
const mealOptions = document.querySelector('#meal-options');
const shoppingList = document.querySelector('#shopping-list');
const recipe = document.querySelector('#recipe');

let currentProteinInfo = null;

const proteinMeals = {
  broileri: {
    meals: [
      {
        name: 'Broileri-kvinoapannu paahdetuilla vihanneksilla',
        protein: '28 g',
        recipe: {
          title: 'Broileri-kvinoapannu paahdetuilla vihanneksilla',
          ingredients: [
            '400 g broilerin rintafileetä',
            '2 dl kvinoaa',
            '1 parsakaali',
            '1 paprika',
            '1 punasipuli',
            '2 valkosipulinkynttä',
            '2 rkl oliiviöljyä',
            '1 sitruuna',
            'suolaa ja pippuria maun mukaan'
          ],
          steps: [
            'Keitä kvinoa 2 dl vedessä noin 15 minuuttia.',
            'Pilko parsakaali, paprika ja punasipuli.',
            'Sekoita vihannekset oliiviöljyn, suolan ja pippurin kanssa.',
            'Aseta broilerin palat peltille ja purista päälle sitruunamehua.',
            'Paahda uunissa 200 °C noin 20 minuuttia.',
            'Tarjoile yhdessä kvinoan kanssa.'
          ]
        }
      },
      {
        name: 'Kana-ceasarsalaatti täysjyväleivällä',
        protein: '32 g',
        recipe: {
          title: 'Kana-ceasarsalaatti täysjyväleivällä',
          ingredients: [
            '300 g broilerin rintafileetä',
            '200 g romaineita',
            '50 g parmesaania',
            '4 rkl ceasarkastiketta',
            '2 viipaletta täysjyväleipää',
            '1 rkl oliiviöljyä',
            'suolaa ja pippuria'
          ],
          steps: [
            'Paista broilerin rintafileet pannulla noin 6-7 minuuttia per puoli.',
            'Leikkaa broileri viipaleiksi.',
            'Pese ja pilko romainelettika.',
            'Sekoita salaatti ceasarkastikkeella.',
            'Aseta broileri salaatin päälle.',
            'Lisää parmesaaniraasteita ja täysjyvärouskuja.',
            'Tarjoile täysjyväleivän kanssa.'
          ]
        }
      },
      {
        name: 'Broilerinugetit uunissa ja bataattiranskalaiset',
        protein: '30 g',
        recipe: {
          title: 'Broilerinugetit uunissa ja bataattiranskalaiset',
          ingredients: [
            '500 g broilerin rintafileetä',
            '100 g täysjyvaleipämurustelua',
            '2 kananmunaa',
            '400 g bataattia',
            '2 rkl öljyä',
            'suolaa, pippuria ja yrttejä'
          ],
          steps: [
            'Leikkaa broileri kuutioiksi.',
            'Sekoita munat ja kastaa nugetit siinä, sitten punnittu leivänmuru.',
            'Aseta peltille ja paahda 200 °C noin 20 minuuttia.',
            'Pilko bataatti pieniksi ja paahda toisella pellillä öljyn kanssa 25 minuuttia.',
            'Tarjoile nugetit ja ranskalaiset yhdessä.'
          ]
        }
      },
      {
        name: 'Broilerifajita tortillojen kanssa',
        protein: '29 g',
        recipe: {
          title: 'Broilerifajita tortillojen kanssa',
          ingredients: [
            '400 g broilerin rintafileetä',
            '8 pienempää tortillaa',
            '2 paprikaa',
            '1 sipuli',
            '2 rkl fajita-mauste',
            '2 rkl öljyä',
            'tuore koriander, juusto, smetana'
          ],
          steps: [
            'Leikkaa broileri ja vihannekset pieniksi suikaleiksi.',
            'Kuumenna voi pannulla ja lisää broileri.',
            'Lisää mauste ja vihannekset, paista kunnes kaikki on kypsää.',
            'Lämmitä tortillat.',
            'Täytä tortillat broileriseoksella ja lisää koriander, juusto ja smetana.',
            'Tarjoile kuumana.'
          ]
        }
      },
      {
        name: 'Kana-grekosalaatti fetajuustolla',
        protein: '27 g',
        recipe: {
          title: 'Kana-grekosalaatti fetajuustolla',
          ingredients: [
            '350 g broilerin rintafileetä',
            '300 g kirsikkatomaatteja',
            '1 kurkkua',
            '100 g fetajuustoa',
            '50 g mustaherukoita',
            '3 rkl oliiviöljyä',
            '1 rkl balsamiviinietikkaa'
          ],
          steps: [
            'Paista broilerin rintafileet pannulla.',
            'Leikkaa broileri kuutioiksi.',
            'Pilko kurkkua ja tomaareja.',
            'Sekoita kaikki vihannekset kulhoon.',
            'Lisää mustaherukka.',
            'Valmista kastike oliivi- ja balsamiviinietikasta.',
            'Kaada kastike salaattiin ja sekoita.',
            'Lisää fetajuustoa ja tarjoile.'
          ]
        }
      },
      {
        name: 'Kana-kasviswokki',
        protein: '31 g',
        recipe: {
          title: 'Kana-kasviswokki',
          ingredients: [
            '400 g broilerin rintafileetä',
            '1 paprika',
            '1 porkkana',
            '100 g herneitä',
            '2 valkosipulinkynttä',
            '3 rkl soijakastiketta',
            '2 rkl öljyä',
            '1 tl inkivääriä'
          ],
          steps: [
            'Leikkaa broileri ja vihannekset pieniksi paloiksi.',
            'Kuumenna wokissa öljy.',
            'Paista broileri kunnes läpi on kypsää.',
            'Lisää vihannekset ja valkosipuli.',
            'Lisää soijasauce ja inkivääri.',
            'Paista niin kauan kunnes vihannekset ovat kypsät mutta vielä ruskeat.',
            'Tarjoile riisin kanssa.'
          ]
        }
      },
      {
        name: 'Broileri-kikhernecurry',
        protein: '26 g',
        recipe: {
          title: 'Broileri-kikhernecurry',
          ingredients: [
            '350 g broilerin rintafileetä',
            '200 g keitettyjä kikherneitä',
            '1 sipuli',
            '3 rkl curryjauhetta',
            '400 ml kokosmaito',
            '2 rkl öljyä',
            '1 sitruuna',
            'tuore koriander'
          ],
          steps: [
            'Kuullota sipuli öljyssä pannulla.',
            'Lisää curry-jaune ja paista hetki.',
            'Lisää broilerin kuutiot ja paista puolilla kypsää.',
            'Lisää kikherneet ja kokosmaito.',
            'Hauduta noin 15 minuuttia.',
            'Mausta sitruunamehua ja korinteri.',
            'Tarjoile riisin kanssa.'
          ]
        }
      },
      {
        name: 'Kana-avokadosalaatti',
        protein: '25 g',
        recipe: {
          title: 'Kana-avokadosalaatti',
          ingredients: [
            '300 g broilerin rintafileetä',
            '2 avokadoa',
            '150 g lehtikaalia',
            '100 g tomaattia',
            '50 g riikinkukkoa',
            '3 rkl oliiviöljyä',
            '1 rkl lime-mehua'
          ],
          steps: [
            'Paista broilerin rintafileet pannulla.',
            'Leikkaa broileri viipaleiksi.',
            'Pilko avokadot ja tomaatit.',
            'Sekoita lehtikaali ja riikinkukko kulhoon.',
            'Lisää broileri ja avokado.',
            'Valmista kastike oliiviöljystä ja limemehuista.',
            'Kaada kastike ja sekoita.',
            'Tarjoile heti.'
          ]
        }
      },
      {
        name: 'Paistettu kana-riisiannos',
        protein: '33 g',
        recipe: {
          title: 'Paistettu kana-riisiannos',
          ingredients: [
            '400 g broilerin rintafileetä',
            '2 dl pitkäjyväriisiä',
            '1 paprika',
            '1 sipuli',
            '2 porkkana',
            '3 rkl soijakastiketta',
            '2 rkl öljyä'
          ],
          steps: [
            'Keitä riisi pakkauksen ohjeen mukaan.',
            'Leikkaa broileri kuutioiksi.',
            'Kuumenna öljy pannulla ja paista broileri.',
            'Lisää vihannekset ja paista kunnes kypsää.',
            'Lisää soijasauce.',
            'Sekoita riisi broileriin ja vihanneksiin.',
            'Tarjoile kuumana.'
          ]
        }
      },
      {
        name: 'Kanaa ja parsakaalia kerrosvuoassa',
        protein: '30 g',
        recipe: {
          title: 'Kanaa ja parsakaalia kerrosvuoassa',
          ingredients: [
            '400 g broilerin rintafileetä',
            '500 g parsakaalia',
            '200 ml kermaa',
            '100 g juustoa',
            '1 sipuli',
            '2 rkl voita',
            'suolaa ja pippuria'
          ],
          steps: [
            'Pilko broilerin rintafileet paloiksi ja paista pannulla.',
            'Keittä parsakaali noin 5 minuuttia.',
            'Kuullota sipuli voissa ja lisää kerma.',
            'Voitele vuoka ja aseta broileri pohjalle.',
            'Lisää parsakaali ja kaada kastike päälle.',
            'Ripottele juusto päälle.',
            'Paahda 180 °C noin 20 minuuttia kunnes juusto on ruskea.'
          ]
        }
      }
    ],
    shopping: ['Broilerin rintafileet', 'Kvinoa', 'Paprika', 'Parsakaali', 'Punasipuli', 'Valkosipuli', 'Oliiviöljy', 'Sitruuna', 'Täysjyväleipä']
  },
  lohi: {
    meals: [
      {
        name: 'Uunilohi sitruuna-tillikastikkeella',
        protein: '34 g',
        recipe: {
          title: 'Uunilohi sitruuna-tillikastikkeella',
          ingredients: [
            '500 g lohifileetä',
            '1 sitruuna',
            '2 rkl oliiviöljyä',
            '1 rkl silputtua tuoretta tilliä',
            '1 pieni parsakaali',
            '2 valkosipulinkynttä',
            'suolaa ja pippuria'
          ],
          steps: [
            'Lämmitä uuni 200 °C.',
            'Aseta lohifileet uunipellille.',
            'Purista päälle sitruunamehua ja mausta suolalla ja pippurilla.',
            'Paahda 18–20 minuuttia.',
            'Sekoita tarjoiluun tuoretta tilliä ja paahdettuja vihanneksia.'
          ]
        }
      },
      {
        name: 'Lohi-kvinoasalaatti',
        protein: '29 g',
        recipe: {
          title: 'Lohi-kvinoasalaatti',
          ingredients: [
            '300 g lohifileetä',
            '2 dl kvinoaa',
            '100 g parsakaalia',
            '100 g punajuuria',
            '1 avokado',
            '3 rkl oliiviöljyä',
            '1 rkl mustapippuria'
          ],
          steps: [
            'Keitä kvinoa pakkauksen ohjeen mukaan.',
            'Paista lohifileet pannulla noin 5-6 minuuttia per puoli.',
            'Leikkaa lohi paloiksi.',
            'Sekoita jäähtynyt kvinoa pilkottujen vihanneksien kanssa.',
            'Lisää lohi.',
            'Valmista kastike oliiviöljystä ja mustapippurista.',
            'Kaada kastike ja sekoita.',
            'Tarjoile välittömästi.'
          ]
        }
      },
      {
        name: 'Lohi-kasviswokki',
        protein: '31 g',
        recipe: {
          title: 'Lohi-kasviswokki',
          ingredients: [
            '350 g lohifileetä',
            '100 g siirtosienistä',
            '1 paprika',
            '100 g herneitä',
            '2 valkosipulinkynttä',
            '3 rkl soijakastiketta',
            '1 rkl seesamiöljyä'
          ],
          steps: [
            'Leikkaa lohi paloiksi.',
            'Kuumenna wokkissa öljy.',
            'Paista lohi hetken ja ota pois.',
            'Lisää vihannekset ja sienet.',
            'Paista kunnes vihannekset alkavat muuttua väriä.',
            'Lisää lohi takaisin ja soijasauce.',
            'Paista vielä hetki ja tarjoile riisin kanssa.'
          ]
        }
      },
      {
        name: 'Lohikeitto perunoilla',
        protein: '27 g',
        recipe: {
          title: 'Lohikeitto perunoilla',
          ingredients: [
            '400 g lohifileetä',
            '400 g perunaa',
            '1 sipuli',
            '1 porkkaana',
            '500 ml kalaliemi',
            '200 ml kermaa',
            '2 rkl voita',
            'tuore dill'
          ],
          steps: [
            'Leikkaa perunat ja porkkana kuutioiksi.',
            'Kuullota sipuli voissa kattilassa.',
            'Lisää perunat, porkkana ja kalaliemi.',
            'Keitä noin 15 minuuttia.',
            'Lisää lohipalat ja kermaa.',
            'Keitä niin kauan että kaikki on pehmeää.',
            'Mausta ja lisää tuoretta dilliä.',
            'Tarjoile kuumana.'
          ]
        }
      },
      {
        name: 'Lohi-nuudeliannos',
        protein: '30 g',
        recipe: {
          title: 'Lohi-nuudeliannos',
          ingredients: [
            '350 g lohifileetä',
            '250 g niin kutsuttuja nupaliannoksia (udon)',
            '100 g parsakaalia',
            '2 valkosipulinkynttä',
            '3 rkl soijakastiketta',
            '1 tl seesamiöljyä',
            'granaattiomenan siemeniä'
          ],
          steps: [
            'Keittä nuudelit pakkauksen ohjeen mukaan ja kuivata ne.',
            'Paista lohifileet pannulla.',
            'Leikkaa lohi suikaleiksi.',
            'Kuumenna wokkissa öljy ja paista parsakaali, valkosipuli ja lohi.',
            'Sekoita nuudelit ja soijasauce.',
            'Paista kunnes kaikki on lämpimää.',
            'Korista granaattiomenan siemenillä ja tarjoile.'
          ]
        }
      },
      {
        name: 'Paistettu lohi ja parsakaali',
        protein: '33 g',
        recipe: {
          title: 'Paistettu lohi ja parsakaali',
          ingredients: [
            '450 g lohifileetä',
            '500 g parsakaalia',
            '2 valkosipulinkynttä',
            '3 rkl oliiviöljyä',
            '1 sitruuna',
            'suolaa ja pippuria'
          ],
          steps: [
            'Keittä parsakaali noin 5 minuuttia kylmässä vedessä.',
            'Kuulota valkosipuli oliiviöljyssä pannulla.',
            'Lisää parsakaali ja paista hetki.',
            'Lisää lohifileet ja paista 6-8 minuuttia.',
            'Purista päälle sitruunamehua.',
            'Mausta suolalla ja pippurilla.',
            'Tarjoile kuumana.'
          ]
        }
      },
      {
        name: 'Lohirulla fetalla ja pinaatilla',
        protein: '28 g',
        recipe: {
          title: 'Lohirulla fetalla ja pinaatilla',
          ingredients: [
            '400 g lohifileetä',
            '200 g tuoretta pinaattia',
            '100 g fetajuustoa',
            '8 pienempää tortillaa',
            '1 sitruuna',
            'suolaa ja pippuria'
          ],
          steps: [
            'Paista lohifileet pannulla ja leikkaa paloiksi.',
            'Kuullota pinaatti pannulla hetken.',
            'Sekoita lohi, pinaatti ja murua fetajuusto.',
            'Täytä tortillat seoksella.',
            'Rullaa tortillat.',
            'Voit paista ne pannulla hetken tai tarjoa kylminä.',
            'Purista päälle sitruunamehua.'
          ]
        }
      },
      {
        name: 'Lohi-avokadopasta',
        protein: '26 g',
        recipe: {
          title: 'Lohi-avokadopasta',
          ingredients: [
            '350 g lohifileetä',
            '300 g pastaa',
            '2 avokadoa',
            '1 sitruuna',
            '2 valkosipulinkynttä',
            '3 rkl oliiviöljyä',
            'tuore basilika'
          ],
          steps: [
            'Keittä pasta pakkauksen ohjeen mukaan.',
            'Paista lohi pannulla ja leikkaa paloiksi.',
            'Sekoita avokadot haarukalla.',
            'Lisää oliiviöljy, sitruunamehu ja valkosipuli avokadoihin.',
            'Sekoita lohi avokadoseokseen.',
            'Sekoita kuumaan pastaan avokado-lohiseoksen kanssa.',
            'Korista basilikalla ja tarjoile heti.'
          ]
        }
      },
      {
        name: 'Lohi-tomaattipasta',
        protein: '27 g',
        recipe: {
          title: 'Lohi-tomaattipasta',
          ingredients: [
            '350 g lohifileetä',
            '300 g pastaa',
            '400 g tuoreita tomaatteja tai tomaattimurskan',
            '3 valkosipulinkynttä',
            '2 rkl oliiviöljyä',
            'tuore basilika',
            'suolaa ja pippuria'
          ],
          steps: [
            'Keittä pasta pakkauksen ohjeen mukaan.',
            'Kuullota valkosipuli oliiviöljyssä pannulla.',
            'Lisää tomaatit ja keitä hetki.',
            'Lisää lohipalat ja paista kunnes lohi on kypsää.',
            'Sekoita pasta tomaatti-lohikastikkeen kanssa.',
            'Mausta ja korista basilikalla.',
            'Tarjoile kuumana.'
          ]
        }
      },
      {
        name: 'Lohi-salaatti seesamkastikkeella',
        protein: '25 g',
        recipe: {
          title: 'Lohi-salaatti seesamkastikkeella',
          ingredients: [
            '300 g lohifileetä',
            '150 g vihreää salaattia',
            '100 g punajuurta',
            '50 g seesamisiemeniä',
            '3 rkl seesamiöljyä',
            '2 rkl riisiviinietikkaa',
            '1 tl soijakastiketta'
          ],
          steps: [
            'Paista lohifileet pannulla ja leikkaa paloiksi.',
            'Sekoita salaatti ja pilkottu punajuuri kulhoon.',
            'Valmista kastike seesamiöljystä, riisiviinietikasta ja soijasta.',
            'Lisää lohi salaattiin.',
            'Kaada kastike päälle.',
            'Korista seesamisiemenillä.',
            'Tarjoile välittömästi.'
          ]
        }
      }
    ],
    shopping: ['Lohifileet', 'Kvinoa', 'Parsakaali', 'Sitruuna', 'Tuore tilli', 'Kirsikkatomaatit', 'Pinaatti', 'Valkosipuli', 'Oliiviöljy']
  },
  nauta: {
    meals: [
      {
        name: 'Härkäpapupata riisin kanssa',
        protein: '28 g',
        recipe: {
          title: 'Härkäpapupata riisin kanssa',
          ingredients: [
            '200 g härkäpavun paloja',
            '100 g naudanlihaa',
            '2 dl täysjyväriisiä',
            '1 sipuli',
            '400 g tomaattimurskan',
            '100 ml naudaliemi',
            '2 rkl öljyä',
            'mausteet'
          ],
          steps: [
            'Keitä riisi pakkauksen ohjeen mukaan.',
            'Kuullota sipuli ja mausta liha öljyssä.',
            'Lisää härkäpavut ja tomaattimurska.',
            'Hauduta noin 20 minuuttia kannen alla.',
            'Sekoita kypsään riisiin.',
            'Tarjoile kuumana.'
          ]
        }
      },
      {
        name: 'Jauheliha-kasviswokki',
        protein: '32 g',
        recipe: {
          title: 'Jauheliha-kasviswokki',
          ingredients: [
            '350 g naudan jauhelihaa',
            '1 paprika',
            '1 porkkana',
            '100 g brokolia',
            '2 valkosipulinkynttä',
            '3 rkl soijakastiketta',
            '2 rkl öljyä'
          ],
          steps: [
            'Kuumenna öljy wokkissa.',
            'Paista jauheliha kunnes se on läpi kypsää.',
            'Lisää vihannekset ja valkosipuli.',
            'Paista kunnes vihannekset ovat pehmeitä mutta vielä ruskeat.',
            'Lisää soijasauce ja sekoita.',
            'Tarjoile riisin kanssa.'
          ]
        }
      },
      {
        name: 'Naudanliha-tacos',
        protein: '30 g',
        recipe: {
          title: 'Naudanliha-tacos',
          ingredients: [
            '350 g naudan jauhelihaa',
            '8 taco-kuorta',
            '1 sipuli',
            '2 rkl taco-mauste',
            'salaatti, tomaatti, juusto, smetana'
          ],
          steps: [
            'Kuullota sipuli pannulla ja lisää liha.',
            'Paista kunnes liha on läpi kypsää.',
            'Lisää taco-mauste ja hetki vettä.',
            'Keitä noin 5 minuuttia.',
            'Lämmitä taco-kuoret.',
            'Täytä kuoret lihalla ja halutulla täytteellä.',
            'Tarjoile heti.'
          ]
        }
      },
      {
        name: 'Paistettua naudanlihaa ja parsakaalia',
        protein: '34 g',
        recipe: {
          title: 'Paistettua naudanlihaa ja parsakaalia',
          ingredients: [
            '400 g naudan pihviä',
            '600 g parsakaalia',
            '3 valkosipulinkynttä',
            '2 rkl öljyä',
            'suolaa ja pippuria'
          ],
          steps: [
            'Mausta lihaa suolalla ja pippurilla.',
            'Paista pannulla niin kauan että ulkopuoli on ruskea (3-4 min per puoli).',
            'Ota liha pois ja anna levätä hetki.',
            'Kuumenna öljy pannulla ja paista parsakaali, valkosipuli mukaan 5-7 minuuttia.',
            'Leikkaa liha viipaleiksi ja aseta parsakaalin päälle.',
            'Tarjoile heti.'
          ]
        }
      },
      {
        name: 'Pihvi ja uunijuurekset',
        protein: '36 g',
        recipe: {
          title: 'Pihvi ja uunijuurekset',
          ingredients: [
            '450 g naudan pihviä',
            '400 g perunaa',
            '2 porkkana',
            '1 sipuli',
            '3 rkl oliiviöljyä',
            'suolaa, pippuria, yrttejä'
          ],
          steps: [
            'Leikkaa juurekset siivoiksi.',
            'Sekoita juurekset oliiviöljyn ja mausteisiin ja aseta peltille.',
            'Paahda 200 °C noin 25 minuuttia.',
            'Lämmitä pannulla öljyä ja paista liha 3-4 minuuttia per puoli.',
            'Mausta.',
            'Anna levätä hetki ja tarjoile juureksien kanssa.'
          ]
        }
      },
      {
        name: 'Naudanliha-kikhernecurry',
        protein: '29 g',
        recipe: {
          title: 'Naudanliha-kikhernecurry',
          ingredients: [
            '300 g naudan jauhelihaa',
            '200 g keitettyjä kikherneitä',
            '1 sipuli',
            '3 rkl curryjauhetta',
            '400 ml kokosmaito',
            '2 rkl öljyä',
            'tuore koriander'
          ],
          steps: [
            'Kuullota sipuli öljyssä.',
            'Lisää curry-jaune ja paista hetki.',
            'Lisää jauheliha ja paista kunnes se on puolilla kypsää.',
            'Lisää kikherneet ja kokosmaito.',
            'Hauduta noin 15 minuuttia.',
            'Korista korinteri ja tarjoile riisin kanssa.'
          ]
        }
      },
      {
        name: 'Härkäsalaatti fetalla',
        protein: '27 g',
        recipe: {
          title: 'Härkäsalaatti fetalla',
          ingredients: [
            '200 g härkäpavun paloja',
            '100 g naudanlihaa',
            '150 g romainelettikaa',
            '100 g tomaattia',
            '50 g fetajuustoa',
            '3 rkl oliiviöljyä',
            '1 rkl balsamiviinietikkaa'
          ],
          steps: [
            'Paista liha pannulla ja pilko.',
            'Pese ja pilko salaatti ja tomaatit.',
            'Sekoita salaatti, tomaatit, härkäpavut ja liha kulhoon.',
            'Valmista kastike öljystä ja etikasta.',
            'Kaada kastike ja sekoita.',
            'Lisää murustettu feta ja tarjoile.'
          ]
        }
      },
      {
        name: 'Jauheliha-pasta bolognese',
        protein: '31 g',
        recipe: {
          title: 'Jauheliha-pasta bolognese',
          ingredients: [
            '400 g naudan jauhelihaa',
            '300 g pastaa',
            '400 g tomaattimurskan',
            '1 sipuli',
            '2 valkosipulinkynttä',
            '2 rkl öljyä',
            'tuore basilika'
          ],
          steps: [
            'Keittä pasta pakkauksen ohjeen mukaan.',
            'Kuullota sipuli ja valkosipuli öljyssä pannulla.',
            'Lisää jauheliha ja paista kunnes se on kypsää.',
            'Lisää tomaattimurska ja hauduta 15-20 minuuttia.',
            'Korista basilikalla.',
            'Sekoita pastaan ja tarjoile.'
          ]
        }
      },
      {
        name: 'Naudanliha-bulgur',
        protein: '28 g',
        recipe: {
          title: 'Naudanliha-bulgur',
          ingredients: [
            '350 g naudan jauhelihaa',
            '2 dl bulguria',
            '1 sipuli',
            '1 paprika',
            '400 g tomaattimurskan',
            '2 rkl öljyä',
            'mausteet'
          ],
          steps: [
            'Kuullota sipuli ja paprika öljyssä.',
            'Lisää liha ja paista kunnes kypsää.',
            'Lisää tomaattimurska ja bulgur.',
            'Hauduta kannen alla noin 15 minuuttia kunnes bulgur on pehmeä.',
            'Mausta ja tarjoile.'
          ]
        }
      },
      {
        name: 'Stroganoff täysjyväriisillä',
        protein: '30 g',
        recipe: {
          title: 'Stroganoff täysjyväriisillä',
          ingredients: [
            '400 g naudan jauhelihaa',
            '2 dl täysjyväriisiä',
            '300 g sieniä',
            '1 sipuli',
            '200 ml kerma',
            '2 rkl voita',
            '1 tl sinappia'
          ],
          steps: [
            'Keitä riisi pakkauksen ohjeen mukaan.',
            'Kuullota sipuli voissa.',
            'Lisää jauheliha ja paista kunnes kypsää.',
            'Lisää sienet ja paista hetki.',
            'Lisää kerma ja sinappi.',
            'Keitä hetki.',
            'Sekoita riisiin ja tarjoile.'
          ]
        }
      }
    ],
    shopping: ['Jauheliha', 'Täysjyväriisi', 'Sipuli', 'Valkosipuli', 'Paprika', 'Tomaattimurska', 'Sienet', 'Kerma', 'Mausteet']
  },
  tofu: {
    meals: [
      {
        name: 'Tofu-kikhernewokki',
        protein: '24 g',
        recipe: {
          title: 'Tofu-kikhernewokki',
          ingredients: [
            '400 g kiinteää tofua',
            '200 g keitettyjä kikherneitä',
            '1 paprika',
            '1 pieni parsakaali',
            '2 dl cashew-pähkinöitä',
            '3 rkl soijakastiketta',
            '1 rkl raastettua inkivääriä',
            '2 valkosipulinkynttä',
            '2 rkl öljyä'
          ],
          steps: [
            'Kuivaa tofu ja leikkaa kuutioiksi.',
            'Paista tofu pannulla rapeaksi.',
            'Lisää keitetyt kikherneet ja pilkotut vihannekset.',
            'Mausta soijalla ja inkiväärillä.',
            'Koristele cashew-pähkinöillä ja tarjoile.'
          ]
        }
      },
      {
        name: 'Paistettu tofu kvinoalla',
        protein: '26 g',
        recipe: {
          title: 'Paistettu tofu kvinoalla',
          ingredients: [
            '350 g kiinteää tofua',
            '2 dl kvinoaa',
            '1 paprika',
            '100 g brokolia',
            '2 valkosipulinkynttä',
            '3 rkl soijakastiketta',
            '2 rkl öljyä'
          ],
          steps: [
            'Keitä kvinoa pakkauksen ohjeen mukaan.',
            'Kuivaa ja leikkaa tofu kuutioiksi.',
            'Paista tofu öljyssä kunnes kulmat ovat rapeat.',
            'Lisää vihannekset ja valkosipuli.',
            'Paista kunnes vihannekset ovat pehmeitä.',
            'Lisää soijasauce ja sekoita.',
            'Sekoita kvinoaan ja tarjoile.'
          ]
        }
      },
      {
        name: 'Tofu-kasviscurrykulho',
        protein: '25 g',
        recipe: {
          title: 'Tofu-kasviscurrykulho',
          ingredients: [
            '300 g tofua',
            '200 g keitettyä riisiä',
            '1 paprika',
            '100 g porkkanaraakaa',
            '3 rkl curryjauhetta',
            '200 ml kokosmaito',
            '2 rkl öljyä'
          ],
          steps: [
            'Leikkaa tofu kuutioiksi.',
            'Kuumenna öljy pannulla ja paista tofu hetki.',
            'Lisää curry-jaune ja paista hetki.',
            'Lisää vihannekset ja paista hetki.',
            'Lisää kokosmaito ja hauduta noin 10 minuuttia.',
            'Tarjoile riisin kanssa kulhossa.'
          ]
        }
      },
      {
        name: 'Tofu-salaatti cashew-pähkinöillä',
        protein: '22 g',
        recipe: {
          title: 'Tofu-salaatti cashew-pähkinöillä',
          ingredients: [
            '250 g tofua',
            '150 g lehtikaalia',
            '100 g riikinkukkoa',
            '50 g cashew-pähkinöitä',
            '2 valkosipulinkynttä',
            '3 rkl seesamiöljyä',
            '1 rkl riisiviinietikkaa'
          ],
          steps: [
            'Leikkaa tofu kuutioiksi ja paista pannulla rapeaksi.',
            'Sekoita salaatti ja riikinkukko kulhoon.',
            'Valmista kastike seesamiöljystä, riisiviinietikasta ja valkosipulista.',
            'Lisää tofu salaattiin.',
            'Kaada kastike ja sekoita.',
            'Koristele cashew-pähkinöillä ja tarjoile.'
          ]
        }
      },
      {
        name: 'Paistettu tofu ja parsakaali',
        protein: '28 g',
        recipe: {
          title: 'Paistettu tofu ja parsakaali',
          ingredients: [
            '350 g kiinteää tofua',
            '500 g parsakaalia',
            '3 valkosipulinkynttä',
            '3 rkl soijakastiketta',
            '2 rkl öljyä'
          ],
          steps: [
            'Keittä parsakaali noin 5 minuuttia.',
            'Kuivaa ja leikkaa tofu kuutioiksi.',
            'Paista tofu öljyssä kunnes kulmat ovat ruskeat.',
            'Lisää parsakaali ja valkosipuli.',
            'Mausta soijasauksella.',
            'Paista hetki ja tarjoile.'
          ]
        }
      },
      {
        name: 'Tofu-nuudeliannos',
        protein: '25 g',
        recipe: {
          title: 'Tofu-nuudeliannos',
          ingredients: [
            '300 g tofua',
            '250 g nuudeleita',
            '100 g herneitä',
            '1 porkkana',
            '3 rkl soijakastiketta',
            '1 rkl seesamiöljyä',
            '2 valkosipulinkynttä'
          ],
          steps: [
            'Keittä nuudelit pakkauksen ohjeen mukaan.',
            'Leikkaa tofu ja vihannekset pieniksi paloiksi.',
            'Kuumenna öljy wokkissa ja paista tofu hetki.',
            'Lisää vihannekset ja paista kunnes ne ovat pehmeitä.',
            'Sekoita nuudelit ja soijasauce.',
            'Paista kunnes kaikki on lämpimää ja tarjoile.'
          ]
        }
      },
      {
        name: 'Tofu-buddha bowl',
        protein: '24 g',
        recipe: {
          title: 'Tofu-buddha bowl',
          ingredients: [
            '250 g tofua',
            '200 g keitettyä kvinoaa',
            '100 g bataattia',
            '100 g parsakaalia',
            '50 g pinaattia',
            '3 rkl tahiinia',
            '1 sitruuna'
          ],
          steps: [
            'Paahda bataatti 200 °C noin 20 minuuttia.',
            'Keittä parsakaali hetki.',
            'Leikkaa tofu kuutioiksi ja paista pannulla.',
            'Valmista kastike tahiinista ja sitruunamehuista.',
            'Aseta kvinoa, vihannekset, tofu ja pinaatti kulhoon.',
            'Kaada kastike päälle ja tarjoile.'
          ]
        }
      },
      {
        name: 'Tofu-täytetyt paprikat',
        protein: '23 g',
        recipe: {
          title: 'Tofu-täytetyt paprikat',
          ingredients: [
            '300 g tofua',
            '4 paprikaa',
            '100 g keitettyä riisiä',
            '1 sipuli',
            '100 g tomaattia',
            '2 rkl öljyä',
            'mausteet'
          ],
          steps: [
            'Poista paprikoista kanta ja siemenet.',
            'Leikkaa tofu kuutioiksi.',
            'Kuullota sipuli öljyssä ja lisää tofu.',
            'Lisää pilkottu tomaatti ja keitetty riisi.',
            'Mausta.',
            'Täytä paprikat seoksella.',
            'Paahda 180 °C noin 20 minuuttia.'
          ]
        }
      },
      {
        name: 'Tofu-kasvispasta',
        protein: '24 g',
        recipe: {
          title: 'Tofu-kasvispasta',
          ingredients: [
            '300 g tofua',
            '300 g pastaa',
            '2 paprikaa',
            '100 g brokolia',
            '400 g tuoreita tomaatteja',
            '3 rkl öljyä',
            'tuore basilika'
          ],
          steps: [
            'Keittä pasta pakkauksen ohjeen mukaan.',
            'Leikkaa tofu ja vihannekset paloiksi.',
            'Kuumenna öljy pannulla ja paista tofu hetki.',
            'Lisää vihannekset ja tomaatit.',
            'Paista kunnes vihannekset ovat pehmeitä.',
            'Sekoita pastaan ja korista basilikalla.'
          ]
        }
      },
      {
        name: 'Tofu-kasviskeitto',
        protein: '21 g',
        recipe: {
          title: 'Tofu-kasviskeitto',
          ingredients: [
            '250 g tofua',
            '100 g porkkana',
            '100 g parsakaalia',
            '100 g perunaa',
            '1 sipuli',
            '800 ml kasvislientä',
            '2 rkl öljyä'
          ],
          steps: [
            'Kuullota sipuli öljyssä kattilassa.',
            'Lisää pilkotut juurekset ja keittävä kasvisliemi.',
            'Keitä noin 15 minuuttia.',
            'Lisää tofupalat ja parsakaali.',
            'Keitä kunnes vihannekset ovat pehmeitä.',
            'Mausta ja tarjoile kuumana.'
          ]
        }
      }
    ],
    shopping: ['Tofu', 'Kikherneet', 'Kvinoa', 'Parsakaali', 'Paprika', 'Pinaatti', 'Cashew-pähkinät', 'Soijakastike', 'Inkivääri']
  },
  pavut: {
    meals: [
      {
        name: 'Linssitomaattipata',
        protein: '22 g',
        recipe: {
          title: 'Linssitomaattipata',
          ingredients: [
            '2 dl punaisia linssejä',
            '400 g tomaattimurskan',
            '1 sipuli',
            '2 valkosipulinkynttä',
            '1 paprika',
            '2 rkl öljyä',
            '5 dl kasvislientä',
            'mausteet'
          ],
          steps: [
            'Kuullota sipuli ja valkosipuli öljyssä kattilassa.',
            'Lisää linssit ja tomaattimurska.',
            'Lisää kasvisliemi ja hauduta noin 25 minuuttia.',
            'Lisää paprika.',
            'Keitä kunnes linssit ovat pehmeät.',
            'Mausta ja tarjoile.'
          ]
        }
      },
      {
        name: 'Kikherne-kasviscurry',
        protein: '23 g',
        recipe: {
          title: 'Kikherne-kasviscurry',
          ingredients: [
            '300 g keitettyjä kikherneitä',
            '1 sipuli',
            '3 rkl curryjauhetta',
            '400 ml kokosmaito',
            '100 g parsakaalia',
            '2 rkl öljyä',
            'tuore koriander'
          ],
          steps: [
            'Kuullota sipuli öljyssä pannulla.',
            'Lisää curry-jaune ja paista hetki.',
            'Lisää kikherneet ja kokosmaito.',
            'Hauduta noin 15 minuuttia.',
            'Lisää parsakaali.',
            'Keitä kunnes parsakaali on pehmeä.',
            'Korista korinteri ja tarjoile riisin kanssa.'
          ]
        }
      },
      {
        name: 'Papu-bowl täysjyväriisillä',
        protein: '24 g',
        recipe: {
          title: 'Papu-bowl täysjyväriisillä',
          ingredients: [
            '200 g keitettyjä kikherneitä',
            '100 g keitettyä linssejä',
            '2 dl täysjyväriisiä',
            '1 avokado',
            '100 g pinaattia',
            '50 g riikinkukkoa',
            '3 rkl tahiinia'
          ],
          steps: [
            'Keitä riisi pakkauksen ohjeen mukaan.',
            'Aseta riisi kulhoon.',
            'Lisää kikherneet, linssit ja pinaatti.',
            'Lisää viipaleiksi leikattu avokado.',
            'Ripottele riikinkukko päälle.',
            'Kaada tahiini päälle ja tarjoile.'
          ]
        }
      },
      {
        name: 'Punainen linssikeitto',
        protein: '20 g',
        recipe: {
          title: 'Punainen linssikeitto',
          ingredients: [
            '2 dl punaisia linssejä',
            '1 sipuli',
            '1 porkkana',
            '1 paprika',
            '800 ml kasvislientä',
            '2 rkl öljyä',
            'tuore tilli'
          ],
          steps: [
            'Kuullota sipuli öljyssä kattilassa.',
            'Lisää linssit ja pilkotut vihannekset.',
            'Lisää kasvisliemi ja keitä noin 25 minuuttia.',
            'Vihannekset voivat olla hieman epämuodostuneita.',
            'Korista tuoreella tilillä ja tarjoile.'
          ]
        }
      },
      {
        name: 'Täytetyt paprikat paahtoleivällä',
        protein: '21 g',
        recipe: {
          title: 'Täytetyt paprikat paahtoleivällä',
          ingredients: [
            '200 g keitettyjä kikherneitä',
            '4 paprikaa',
            '100 g keitettyä riisiä',
            '1 sipuli',
            '50 g juustoa',
            '2 rkl öljyä',
            'mausteet'
          ],
          steps: [
            'Poista paprikoista kanta ja siemenet.',
            'Kuullota sipuli öljyssä ja lisää kikherneet.',
            'Lisää keitetty riisi ja mausta.',
            'Täytä paprikat seoksella.',
            'Ripottele juusto päälle.',
            'Paahda 180 °C noin 20 minuuttia.'
          ]
        }
      },
      {
        name: 'Papu-kasviswrapit',
        protein: '22 g',
        recipe: {
          title: 'Papu-kasviswrapit',
          ingredients: [
            '200 g keitettyjä kikherneitä',
            '8 wraptortillaa',
            '1 paprika',
            '100 g lehtikaalia',
            '1 avokado',
            '1 sitruuna',
            'smetana'
          ],
          steps: [
            'Sekoita kikherneet ja mausta.',
            'Pilko avokado.',
            'Täytä tortillat kikhernesiäväisön, paprikalla, lehtikaalialla ja avokadolla.',
            'Rullaa tortillat.',
            'Purista sitruunamehua päälle ja lisää smetana.',
            'Tarjoile tai paista hetki pannulla.'
          ]
        }
      },
      {
        name: 'Chili sin carne',
        protein: '25 g',
        recipe: {
          title: 'Chili sin carne',
          ingredients: [
            '300 g keitettyjä kikherneitä',
            '100 g keitettyä pavustaa',
            '400 g tomaattimurskan',
            '1 sipuli',
            '1 paprika',
            '2 rkl chili-pasta',
            '2 rkl öljyä'
          ],
          steps: [
            'Kuullota sipuli öljyssä kattilassa.',
            'Lisää chili-pasta ja paista hetki.',
            'Lisää tomaattimurska, kikherneet ja pavut.',
            'Hauduta noin 20 minuuttia.',
            'Lisää paprika loppuun.',
            'Mausta ja tarjoile.'
          ]
        }
      },
      {
        name: 'Linssejä ja avokadoa',
        protein: '19 g',
        recipe: {
          title: 'Linssejä ja avokadoa',
          ingredients: [
            '200 g keitettyä linssejä',
            '2 avokadoa',
            '100 g romainelettikaa',
            '100 g tomaattia',
            '3 rkl oliiviöljyä',
            '1 rkl lime-mehua'
          ],
          steps: [
            'Sekoita salaatti ja tomaatit kulhoon.',
            'Lisää keitetyt linssit.',
            'Pilko ja lisää avokado.',
            'Valmista kastike oliivi- ja limeistä.',
            'Kaada kastike ja sekoita.',
            'Tarjoile välittömästi.'
          ]
        }
      },
      {
        name: 'Papu-tomaattisalaatti',
        protein: '18 g',
        recipe: {
          title: 'Papu-tomaattisalaatti',
          ingredients: [
            '200 g keitettyjä kikherneitä',
            '200 g tuoreita tomaatteja',
            '1 kurkkua',
            '1 sipuli',
            '3 rkl oliiviöljyä',
            '1 rkl balsamiviinietikkaa',
            'tuore persiljaa'
          ],
          steps: [
            'Pilko tomaatit ja kurkkua.',
            'Silppua sipuli.',
            'Sekoita kaikki kikherneiden kanssa.',
            'Valmista kastike oliivi- ja balsamiviinistä.',
            'Kaada kastike ja sekoita.',
            'Korista persiljalla.'
          ]
        }
      },
      {
        name: 'Pavupihvit ja perunamuusi',
        protein: '24 g',
        recipe: {
          title: 'Pavupihvit ja perunamuusi',
          ingredients: [
            '300 g keitettyä pavustaa (sekoitus)',
            '100 g täysjyväleipämurustelua',
            '1 kananmuna',
            '600 g perunaa',
            '100 ml maitoa',
            '2 rkl voita',
            'suolaa ja pippuria'
          ],
          steps: [
            'Silppua keitetyt pavut ja sekoita leivänmuruihin ja munaan.',
            'Muovaa pihveiksi ja paista pannulla öljyssä.',
            'Keitä perunat pehmeiksi.',
            'Soseuta peruna maitoon ja voihin.',
            'Mausta.',
            'Tarjoile pihvit perunamuussin kanssa.'
          ]
        }
      }
    ],
    shopping: ['Linssit', 'Kikherneet', 'Tomaattimurska', 'Sipuli', 'Valkosipuli', 'Paprika', 'Täysjyväriisi', 'Mausteet', 'Avokado']
  },
  kananmunat: {
    meals: [
      {
        name: 'Omeletti pinaatilla ja sieniä',
        protein: '26 g',
        recipe: {
          title: 'Omeletti pinaatilla, sienillä ja fetajuustolla',
          ingredients: [
            '4 kananmunaa',
            '100 g tuoretta pinaattia',
            '150 g sieniä',
            '50 g fetajuustoa',
            '2 rkl voita tai öljyä',
            'suolaa ja pippuria maun mukaan'
          ],
          steps: [
            'Riko munat kulhoon ja vatkaa ne kevyesti.',
            'Paista sienet ja pinaatti pannulla.',
            'Kaada munaseos pannulle ja lisää murustettu feta.',
            'Paista kunnes omeletti on hyytynyt.',
            'Taita ja tarjoile.'
          ]
        }
      },
      {
        name: 'Munakas vihanneksilla',
        protein: '25 g',
        recipe: {
          title: 'Munakas vihanneksilla',
          ingredients: [
            '6 kananmunaa',
            '1 paprika',
            '100 g parsakaalia',
            '1 sipuli',
            '2 rkl voita',
            'suolaa ja pippuria'
          ],
          steps: [
            'Pilko vihannekset pieniksi.',
            'Kuullota vihannekset voissa pannulla.',
            'Riko munat kulhoon ja vatkaa.',
            'Kaada munaseos pannulle.',
            'Paista kunnes munat ovat hyytyneet.',
            'Mausta ja tarjoile kuumana.'
          ]
        }
      },
      {
        name: 'Paistetut munat täysjyväleivällä',
        protein: '22 g',
        recipe: {
          title: 'Paistetut munat täysjyväleivällä',
          ingredients: [
            '3 kananmunaa',
            '2 viipaletta täysjyväleipää',
            '1 tomaatti',
            '100 g lehtikaalia',
            '1 rkl voita',
            'tuore basilika'
          ],
          steps: [
            'Paista leivä.',
            'Paista munat pannulla voissa.',
            'Levitä basilika leivään.',
            'Aseta munat ja tomaatti leivään.',
            'Lisää lehtikaali.',
            'Tarjoile välittömästi.'
          ]
        }
      },
      {
        name: 'Kananmunasalaatti',
        protein: '24 g',
        recipe: {
          title: 'Kananmunasalaatti',
          ingredients: [
            '4 kananmunaa',
            '150 g lehtikaalia',
            '100 g tomaattia',
            '1 kurkkua',
            '3 rkl oliiviöljyä',
            '1 rkl sinappia'
          ],
          steps: [
            'Keittä munat koviksi.',
            'Kuori ja pilko munat.',
            'Sekoita salaatti ja pilkotut vihannekset kulhoon.',
            'Lisää kananmunat.',
            'Valmista kastike oliivista ja sinapista.',
            'Kaada kastike ja sekoita.'
          ]
        }
      },
      {
        name: 'Munakasjuustotortilla',
        protein: '27 g',
        recipe: {
          title: 'Munakasjuustotortilla',
          ingredients: [
            '6 kananmunaa',
            '1 tortilla',
            '50 g juustoa',
            '1 paprika',
            '1 sipuli',
            '2 rkl voita'
          ],
          steps: [
            'Pilko paprika ja sipuli.',
            'Kuullota vihannekset voissa pannulla.',
            'Riko munat ja vatkaa.',
            'Kaada munaseos pannulle.',
            'Paista kunnes puoli-hyytynyt, sitten ripottele juusto.',
            'Taita munakas tortillaan ja tarjoile.'
          ]
        }
      },
      {
        name: 'Kananmuna-avokadoleipä',
        protein: '20 g',
        recipe: {
          title: 'Kananmuna-avokadoleipä',
          ingredients: [
            '2 kananmunaa',
            '1 avokado',
            '2 viipaletta täysjyväleipää',
            '1 tomaatti',
            '1 rkl voita',
            'limemehu'
          ],
          steps: [
            'Keittä munat pehmeiksi ja pilko.',
            'Paista leivä.',
            'Levitä voita leivään.',
            'Aseta munat ja tomaatti.',
            'Lisää viipaleiksi leikattu avokado ja purista päälle limemehua.',
            'Tarjoile välittömästi.'
          ]
        }
      },
      {
        name: 'Munakas kasvipadalla',
        protein: '25 g',
        recipe: {
          title: 'Munakas kasvipadalla',
          ingredients: [
            '6 kananmunaa',
            '100 g brokolia',
            '100 g porkkana',
            '100 g kukkakaalia',
            '2 rkl voita',
            'mausteet'
          ],
          steps: [
            'Keittä vihannekset kunnes ne ovat hyvin pehmeitä.',
            'Riko munat ja vatkaa.',
            'Aseta vihannekset voiteletulle pellille.',
            'Kaada munaseos vihanneksille.',
            'Paista 180 °C noin 15 minuuttia kunnes munat ovat hyytyneet.'
          ]
        }
      },
      {
        name: 'Frittata parsakaalilla',
        protein: '28 g',
        recipe: {
          title: 'Frittata parsakaalilla',
          ingredients: [
            '8 kananmunaa',
            '300 g parsakaalia',
            '50 g juustoa',
            '2 valkosipulinkynttä',
            '2 rkl öljyä',
            'suolaa ja pippuria'
          ],
          steps: [
            'Keittä parsakaali noin 5 minuuttia.',
            'Aseta parsakaali voiteletulle uunipellille.',
            'Riko munat kulhoon ja vatkaa.',
            'Kaada munaseos parsakaalin päälle.',
            'Ripottele juusto päälle.',
            'Paahda 180 °C noin 20 minuuttia kunnes munat ovat hyytyneet.'
          ]
        }
      },
      {
        name: 'Munakas tomaatti-basilikalla',
        protein: '23 g',
        recipe: {
          title: 'Munakas tomaatti-basilikalla',
          ingredients: [
            '6 kananmunaa',
            '200 g tuoreita tomaatteja',
            '3 rkl tuoretta basilikaa',
            '2 valkosipulinkynttä',
            '2 rkl öljyä',
            'suolaa ja pippuria'
          ],
          steps: [
            'Kuullota valkosipuli öljyssä pannulla.',
            'Lisää pilkotut tomaatit.',
            'Paista hetki, sitten lisää basilika.',
            'Riko munat ja vatkaa sekä kaada pannulle.',
            'Paista kunnes munat ovat hyytyneet.',
            'Tarjoile kuumana.'
          ]
        }
      },
      {
        name: 'Paistetut munat ja quinoa',
        protein: '22 g',
        recipe: {
          title: 'Paistetut munat ja quinoa',
          ingredients: [
            '3 kananmunaa',
            '2 dl kvinoaa',
            '100 g brokolia',
            '1 paprika',
            '2 rkl öljyä',
            'suolaa ja pippuria'
          ],
          steps: [
            'Keitä kvinoa pakkauksen ohjeen mukaan.',
            'Paista vihannekset öljyssä pannulla.',
            'Aseta kvinoa lautaselle.',
            'Paista munat ja aseta kvinoan päälle.',
            'Lisää vihannekset sivuun ja tarjoile.'
          ]
        }
      }
    ],
    shopping: ['Kananmunat', 'Pinaatti', 'Sieniä', 'Fetajuusto', 'Täysjyväleipä', 'Avokado', 'Tomaatti', 'Sipuli', 'Yrtit']
  },
  maitotuotteet: {
    meals: [
      {
        name: 'Rahka-marjasmoothie',
        protein: '18 g',
        recipe: {
          title: 'Rahka-marjasmoothie',
          ingredients: [
            '200 g maitorahkaa',
            '1 banaani',
            '150 g pakastemarjoja',
            '1 dl maitoa tai kasvimaitoa',
            '1 rkl hunajaa',
            '1 rkl chia-siemeniä tai pellavansiemeniä'
          ],
          steps: [
            'Sekoita blenderissä rahka, marjat ja banaani.',
            'Lisää vettä tai maitoa sopiva määrä.',
            'Blendaa tasaiseksi.',
            'Tarjoile siemenillä ja marjoilla.'
          ]
        }
      },
      {
        name: 'Kreikkalainen jogurtti granolalla',
        protein: '20 g',
        recipe: {
          title: 'Kreikkalainen jogurtti granolalla',
          ingredients: [
            '200 g kreikkalaista jogurttia',
            '50 g granolaa',
            '50 g tuoreita marjoja',
            '1 rkl hunajaa',
            '1 rkl pähkinöitä'
          ],
          steps: [
            'Aseta jogurti kulhoon.',
            'Ripottele granuolaoksi.',
            'Lisää marjat.',
            'Kaada hunaja päälle.',
            'Koristele pähkinöillä ja tarjoile heti.'
          ]
        }
      },
      {
        name: 'Raejuusto-kasvissalaatti',
        protein: '22 g',
        recipe: {
          title: 'Raejuusto-kasvissalaatti',
          ingredients: [
            '150 g raejuustoa',
            '150 g lehtikaalia',
            '100 g tomaattia',
            '50 g kurkkua',
            '50 g radikkaalia',
            '3 rkl oliiviöljyä'
          ],
          steps: [
            'Sekoita salaatti ja pilkotut vihannekset kulhoon.',
            'Lisää raejuusto.',
            'Kaada öljy päälle.',
            'Sekoita ja tarjoile.'
          ]
        }
      },
      {
        name: 'Rahka-mysliannos',
        protein: '19 g',
        recipe: {
          title: 'Rahka-mysliannos',
          ingredients: [
            '200 g maitorahkaa',
            '50 g täysjyvämurotaria',
            '50 g tuoreita marjoja',
            '1 rkl hunajaa',
            'ripaus kanelia'
          ],
          steps: [
            'Aseta rahka kulhoon.',
            'Ripottele myslit päälle.',
            'Lisää marjat.',
            'Kaada hunaja ja kanelia.',
            'Sekoita hieman ja tarjoile.'
          ]
        }
      },
      {
        name: 'Juustoinen kasviskeitto',
        protein: '21 g',
        recipe: {
          title: 'Juustoinen kasviskeitto',
          ingredients: [
            '100 g juustoa',
            '1 porkkana',
            '1 peruna',
            '1 sipuli',
            '100 g parsakaalia',
            '600 ml kasvislientä',
            '2 rkl voita'
          ],
          steps: [
            'Kuullota sipuli voissa kattilassa.',
            'Lisää pilkotut juurekset ja kasvisliemi.',
            'Keitä noin 15 minuuttia.',
            'Lisää parsakaali.',
            'Keitä kunnes vihannekset ovat pehmeitä.',
            'Lisää pilkottu juusto ja sekoita kunnes juusto sulaa.',
            'Mausta ja tarjoile.'
          ]
        }
      },
      {
        name: 'Maitoproteiinipannarit',
        protein: '24 g',
        recipe: {
          title: 'Maitoproteiinipannarit',
          ingredients: [
            '200 g maitotuotteiden seosta (jogurtti + rahka)',
            '2 kananmunaa',
            '100 g vehnäjauhoja',
            '1 banaani',
            'mansikkoja',
            'hunajaa'
          ],
          steps: [
            'Sekoita maitotuotteet, munat ja jauhot.',
            'Lisää silpottu banaani.',
            'Paista pannulla voissa kunnes kulmat ovat ruskeat molemmilta puolilta.',
            'Tarjoile mansikoiden ja hunajan kanssa.'
          ]
        }
      },
      {
        name: 'Jogurttikastike salaatille',
        protein: '15 g',
        recipe: {
          title: 'Jogurttikastike salaatille',
          ingredients: [
            '200 g kreikkalaista jogurttia',
            '1 rkl sitruunamehua',
            '1 valkosipulinkynttä',
            'tuoretta tilliä',
            'suolaa ja pippuria'
          ],
          steps: [
            'Silppua tilli ja valkosipuli.',
            'Sekoita jogurti, sitruunamehu, tilli ja valkosipuli.',
            'Mausta suolalla ja pippurilla.',
            'Käytä salaattiin tai kebabeihin.'
          ]
        }
      },
      {
        name: 'Raakasalaatti raejuustolla',
        protein: '18 g',
        recipe: {
          title: 'Raakasalaatti raejuustolla',
          ingredients: [
            '150 g raejuustoa',
            '100 g porkkanaa',
            '100 g punajuurta',
            '50 g saksansinappalia',
            '3 rkl oliiviöljyä'
          ],
          steps: [
            'Raastitta porkkana ja punajuuri.',
            'Sekoita saksansinappelin kanssa.',
            'Lisää raejuusto.',
            'Kaada öljy päälle.',
            'Sekoita ja tarjoile kylmänä.'
          ]
        }
      },
      {
        name: 'Kreikkalainen jogurttibowl',
        protein: '19 g',
        recipe: {
          title: 'Kreikkalainen jogurttibowl',
          ingredients: [
            '200 g kreikkalaista jogurttia',
            '50 g granuolaa',
            '50 g tuoreita marjoja',
            '50 g pähkinöitä',
            '1 rkl hunajaa'
          ],
          steps: [
            'Aseta jogurti kulhoon.',
            'Kerrostele granolaa ja marjoja.',
            'Koristele pähkinöillä.',
            'Kaada hunaja päälle.',
            'Tarjoile välittömästi.'
          ]
        }
      },
      {
        name: 'Kasviskeitto parmesaanilla',
        protein: '17 g',
        recipe: {
          title: 'Kasviskeitto parmesaanilla',
          ingredients: [
            '50 g parmesaania',
            '1 porkkana',
            '1 peruna',
            '1 selleri',
            '100 g parsakaalia',
            '600 ml kasvislientä',
            '2 rkl öljyä'
          ],
          steps: [
            'Kuullota vihannekset öljyssä kattilassa.',
            'Lisää kasvisliemi.',
            'Keitä noin 15 minuuttia.',
            'Lisää parsakaali.',
            'Keitä kunnes vihannekset ovat pehmeitä.',
            'Ripottele parmesaania päälle ja tarjoile kuumana.'
          ]
        }
      }
    ],
    shopping: ['Rahka', 'Kreikkalainen jogurtti', 'Raejuusto', 'Marjat', 'Täysjyvämurot', 'Pähkinät', 'Hunaja', 'Vihannekset', 'Sitruuna']
  },
  seitan: {
    meals: [
      {
        name: 'Seitan-kasviswokki',
        protein: '30 g',
        recipe: {
          title: 'Seitan-kasviswokki',
          ingredients: [
            '300 g seitania',
            '1 paprika',
            '1 pieni parsakaali',
            '1 sipuli',
            '2 valkosipulinkynttä',
            '2 rkl soijakastiketta',
            '1 rkl seesamiöljyä',
            '2 dl vihanneksia (esim. porkkana, herneet)',
            'suolaa ja pippuria maun mukaan'
          ],
          steps: [
            'Leikkaa seitan suikaleiksi.',
            'Paista seitan pannulla seesamiöljyssä.',
            'Lisää pilkottu sipuli, valkosipuli ja vihannekset.',
            'Mausta soijakastikkeella, suolalla ja pippurilla.',
            'Paista kunnes vihannekset ovat pehmeitä ja seitan saanut väriä.'
          ]
        }
      },
      {
        name: 'Vegaani-tofu bowl',
        protein: '24 g',
        recipe: {
          title: 'Vegaani-tofu bowl',
          ingredients: [
            '200 g tofua',
            '200 g keitettyä kvinoaa',
            '100 g bataattia',
            '100 g parsakaalia',
            '50 g kikherneitä',
            '3 rkl tahiinia',
            '1 sitruuna'
          ],
          steps: [
            'Paahda bataatti 200 °C noin 20 minuuttia.',
            'Keittä parsakaali hetki.',
            'Leikkaa tofu kuutioiksi ja paista.',
            'Valmista kastike tahiinista ja sitruunamehuista.',
            'Aseta kvinoa, vihannekset ja tofu kulhoon.',
            'Kaada kastike päälle ja tarjoile.'
          ]
        }
      },
      {
        name: 'Seitan-tortillat',
        protein: '28 g',
        recipe: {
          title: 'Seitan-tortillat',
          ingredients: [
            '250 g seitania',
            '8 tortillaa',
            '1 paprika',
            '100 g lehtikaalia',
            '1 avokado',
            '1 sitruuna',
            'smetana'
          ],
          steps: [
            'Leikkaa seitan suikaleiksi ja paista pannulla.',
            'Pilko paprika ja lehtikaali.',
            'Täytä tortillat seitanilla, paprikalla, lehtikaalilla ja avokadolla.',
            'Rullaa tortillat.',
            'Purista sitruunamehua päälle ja lisää smetana.',
            'Tarjoile tai paista hetki.'
          ]
        }
      },
      {
        name: 'Kasvispihvit ja salaatti',
        protein: '22 g',
        recipe: {
          title: 'Kasvispihvit ja salaatti',
          ingredients: [
            '200 g seitania tai vegaanisen pihvin sekaa',
            '150 g lehtikaalia',
            '100 g tomaattia',
            '50 g riikinkukkoa',
            '3 rkl oliiviöljyä',
            '1 rkl balsamiviinietikkaa'
          ],
          steps: [
            'Muovaa pihvit ja paista pannulla öljyssä.',
            'Sekoita salaatti ja riikinkukko kulhoon.',
            'Pilko tomaatti ja lisää salaattiin.',
            'Valmista kastike oliivista ja balsamiviinistä.',
            'Aseta pihvit salaatin päälle.',
            'Kaada kastike ja tarjoile.'
          ]
        }
      },
      {
        name: 'Seitan-burner',
        protein: '29 g',
        recipe: {
          title: 'Seitan-burner',
          ingredients: [
            '300 g seitania',
            '1 burner-sämpylä',
            '1 tomaatti',
            '100 g lehtikaalia',
            '1 sipuli',
            '2 rkl öljyä',
            'salaattikastike'
          ],
          steps: [
            'Paista seitan viipaleiksi pannulla.',
            'Leikkaa sämpylä ja levitä kastike sisäpuolelle.',
            'Aseta seitanviipaleet sämpylään.',
            'Lisää tomaatti, lehtikaali ja sipuli.',
            'Tarjoile kuumana.'
          ]
        }
      },
      {
        name: 'Kasviscurry seitanilla',
        protein: '26 g',
        recipe: {
          title: 'Kasviscurry seitanilla',
          ingredients: [
            '250 g seitania',
            '1 sipuli',
            '3 rkl curryjauhetta',
            '400 ml kokosmaito',
            '100 g parsakaalia',
            '2 rkl öljyä',
            'tuore koriander'
          ],
          steps: [
            'Leikkaa seitan paloiksi.',
            'Kuullota sipuli öljyssä ja lisää curry-jaune.',
            'Paista hetki, sitten lisää seitan.',
            'Lisää kokosmaito ja hauduta noin 15 minuuttia.',
            'Lisää parsakaali ja keitä kunnes pehmeää.',
            'Korista korinteri ja tarjoile riisin kanssa.'
          ]
        }
      },
      {
        name: 'Vegaani-bolognese',
        protein: '23 g',
        recipe: {
          title: 'Vegaani-bolognese',
          ingredients: [
            '200 g silputtu seitan',
            '300 g pastaa',
            '400 g tomaattimurskan',
            '1 sipuli',
            '2 valkosipulinkynttä',
            '2 rkl öljyä',
            'tuore basilika'
          ],
          steps: [
            'Keittä pasta pakkauksen ohjeen mukaan.',
            'Kuullota sipuli ja valkosipuli öljyssä.',
            'Lisää seitan ja paista hetki.',
            'Lisää tomaattimurska ja hauduta 15-20 minuuttia.',
            'Korista basilikalla.',
            'Sekoita pastaan ja tarjoile.'
          ]
        }
      },
      {
        name: 'Seitan-salaatti',
        protein: '25 g',
        recipe: {
          title: 'Seitan-salaatti',
          ingredients: [
            '250 g seitania',
            '150 g lehtikaalia',
            '100 g tomaattia',
            '1 kurkkua',
            '3 rkl oliiviöljyä',
            '1 rkl sinappia'
          ],
          steps: [
            'Leikkaa seitan kuutioiksi ja paista pannulla.',
            'Sekoita salaatti ja pilkotut vihannekset kulhoon.',
            'Lisää seitanpalat.',
            'Valmista kastike oliivista ja sinapista.',
            'Kaada kastike ja sekoita.',
            'Tarjoile välittömästi.'
          ]
        }
      },
      {
        name: 'Seitan-nuudelit',
        protein: '27 g',
        recipe: {
          title: 'Seitan-nuudelit',
          ingredients: [
            '300 g seitania',
            '250 g nuudeleita',
            '100 g herneitä',
            '1 porkkana',
            '3 rkl soijakastiketta',
            '1 rkl seesamiöljyä',
            '2 valkosipulinkynttä'
          ],
          steps: [
            'Keittä nuudelit pakkauksen ohjeen mukaan.',
            'Leikkaa seitan ja vihannekset pieniksi paloiksi.',
            'Kuumenna öljy wokkissa ja paista seitan hetki.',
            'Lisää vihannekset ja paista kunnes ne ovat pehmeitä.',
            'Sekoita nuudelit ja soijasauce.',
            'Paista kunnes kaikki on lämpimää ja tarjoile.'
          ]
        }
      },
      {
        name: 'Paistettu seitan ja parsakaali',
        protein: '28 g',
        recipe: {
          title: 'Paistettu seitan ja parsakaali',
          ingredients: [
            '350 g seitania',
            '500 g parsakaalia',
            '3 valkosipulinkynttä',
            '3 rkl soijakastiketta',
            '2 rkl öljyä',
            'suolaa ja pippuria'
          ],
          steps: [
            'Keittä parsakaali noin 5 minuuttia.',
            'Leikkaa seitan paloiksi.',
            'Paista seitan öljyssä kunnes kulmat ovat ruskeat.',
            'Lisää parsakaali ja valkosipuli.',
            'Mausta soijasauksella.',
            'Paista hetki ja tarjoile.'
          ]
        }
      }
    ],
    shopping: ['Seitan', 'Tofu', 'Kvinoa', 'Paprika', 'Parsakaali', 'Kikherneet', 'Soijakastike', 'Inkivääri', 'Valkosipuli']
  }
};

function getProteinNeed() {
  const weight = Number(weightInput.value);
  const multiplier = Number(trainingType.value);
  if (!weight || weight <= 0) {
    return null;
  }
  return Math.round(weight * multiplier);
}

function renderList(title, items) {
  return `
    <h3>${title}</h3>
    <ul>${items.map(item => `<li>${item}</li>`).join('')}</ul>
  `;
}

function renderMealOptions(title, meals) {
  return `
    <h3>${title}</h3>
    <ul>${meals.map(meal => `<li><span>${meal.name}</span><span class="protein-label">${meal.protein}</span></li>`).join('')}</ul>
  `;
}

function renderRecipe(info) {
  return `
    <h3>Resepti: ${info.title}</h3>
    ${info.ingredients ? `<div><h4>Ainekset</h4><ul>${info.ingredients.map(item => `<li>${item}</li>`).join('')}</ul></div>` : ''}
    <div><h4>Ohjeet</h4><ol>${info.steps.map(step => `<li>${step}</li>`).join('')}</ol></div>
  `;
}

function populateMealChoices(info) {
  mealChoice.innerHTML = `
    <option value="">Valitse ehdotus</option>
    ${info.meals.map(meal => `<option value="${meal.name}">${meal.name} (${meal.protein})</option>`).join('')}
  `;
}

function findMealByName(info, name) {
  return info.meals.find(meal => meal.name === name);
}

calculateButton.addEventListener('click', () => {
  const need = getProteinNeed();
  if (!need) {
    proteinResult.textContent = 'Anna kelvollinen paino.';
    return;
  }
  proteinResult.textContent = `Proteiinitarve noin ${need} g / päivä.`;
});

generateButton.addEventListener('click', () => {
  const source = proteinSource.value;
  const info = proteinMeals[source];
  if (!info) return;

  currentProteinInfo = info;
  populateMealChoices(info);
  mealSelectionHint.textContent = 'Valitse ehdotus listasta ja paina Näytä valittu ruokalaji.';
  dishCard.hidden = false;
  resultsSection.hidden = true;
});

chooseMealButton.addEventListener('click', () => {
  const selectedMealName = mealChoice.value;
  if (!selectedMealName) {
    mealSelectionHint.textContent = 'Valitse ensin ruokalaji.';
    return;
  }

  const selectedMeal = findMealByName(currentProteinInfo, selectedMealName);
  mealSelectionHint.textContent = '';
  if (!currentProteinInfo || !selectedMeal) return;

  mealOptions.innerHTML = `
    <h3>Valittu ruokalaji</h3>
    <p>${selectedMeal.name} — ${selectedMeal.protein}</p>
  `;
  shoppingList.innerHTML = renderList('Ostoslista', selectedMeal.recipe.ingredients);
  recipe.innerHTML = renderRecipe(selectedMeal.recipe);
  resultsSection.hidden = false;
});
